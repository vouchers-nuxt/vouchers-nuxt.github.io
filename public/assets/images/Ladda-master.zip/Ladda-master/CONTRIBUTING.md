# Contributing

Clone the repository and run `npm install` to install development dependencies and compile the project.
Then run `npm start` to watch files for changes and start a static file server for viewing the test site.
Open http://localhost:8000/ in your browser to view the site.
